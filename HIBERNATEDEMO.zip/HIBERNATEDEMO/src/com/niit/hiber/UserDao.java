package com.niit.hiber;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UserDao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int cnt=0;

		Configuration cfg =new Configuration();
		cfg.configure("User.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t=session.beginTransaction();
		
		User u1=new User();
		u1.setName("Raj");
		u1.setPassword("gs");
		u1.setEmail("abc@gmail.com");
		
		session.save(u1);
		t.commit();
		System.out.println("Successfully Saved!");

		session.close();
		sf.close();
		

	}

}
